#include <Geode/Geode.hpp>
#include <Geode/modify/EditorPauseLayer.hpp>
#include <Geode/modify/LevelEditorLayer.hpp>

#include <algorithm>
#include <ctime>
#include <functional>
#include <unordered_map>
#include <vector>

using namespace geode::prelude;
namespace fs = std::filesystem;

namespace {
	// Хэш последних данных по каждому уровню — чтобы не плодить одинаковые копии
	std::unordered_map<std::string, size_t> g_lastHash;

	std::string safeName(std::string s) {
		for (auto& c : s) {
			if (std::string("<>:\"/\\|?*").find(c) != std::string::npos || static_cast<unsigned char>(c) < 32) {
				c = '_';
			}
		}
		if (s.empty()) s = "Unnamed";
		return s;
	}

	std::string xmlEscape(std::string const& s) {
		std::string out;
		for (char c : s) {
			switch (c) {
				case '&': out += "&amp;"; break;
				case '<': out += "&lt;"; break;
				case '>': out += "&gt;"; break;
				default: out += c;
			}
		}
		return out;
	}

	std::string timestamp() {
		std::time_t t = std::time(nullptr);
		std::tm tm{};
#ifdef GEODE_IS_WINDOWS
		localtime_s(&tm, &t);
#else
		localtime_r(&t, &tm);
#endif
		char buf[32];
		std::strftime(buf, sizeof(buf), "%Y%m%d_%H%M%S", &tm);
		return buf;
	}

	void pruneOld(fs::path const& dir, int maxCount) {
		std::vector<fs::path> files;
		std::error_code ec;
		for (auto& e : fs::directory_iterator(dir, ec)) {
			if (e.path().extension() == ".gmd") files.push_back(e.path());
		}
		// Имена начинаются с метки времени, поэтому сортировка по имени = по дате
		std::sort(files.begin(), files.end());
		while (static_cast<int>(files.size()) > maxCount) {
			fs::remove(files.front(), ec);
			files.erase(files.begin());
		}
	}

	void backupLevel(GJGameLevel* level, std::string const& data) {
		auto mod = Mod::get();
		if (!mod->getSettingValue<bool>("enabled") || !level || data.empty()) return;

		std::string name = level->m_levelName;
		auto dir = mod->getSaveDir() / "backups" / safeName(name);
		std::error_code ec;
		fs::create_directories(dir, ec);

		auto key = dir.string();
		auto hash = std::hash<std::string>{}(data);
		if (g_lastHash.count(key) && g_lastHash[key] == hash) return;

		// Формат .gmd — его понимает импорт в GD (через Geode-моды вроде Level Share)
		std::string gmd =
			"<d><k>kCEK</k><i>4</i>"
			"<k>k2</k><s>" + xmlEscape(name) + "</s>"
			"<k>k4</k><s>" + data + "</s>"
			"<k>k5</k><s>" + xmlEscape(std::string(level->m_creatorName)) + "</s>"
			"<k>k13</k><t/>"
			"<k>k21</k><i>2</i>"
			"<k>k50</k><i>35</i></d>";

		auto path = dir / (timestamp() + ".gmd");
		auto res = utils::file::writeString(path, gmd);
		if (res.isErr()) {
			log::error("Не удалось сохранить бэкап: {}", res.unwrapErr());
			return;
		}
		g_lastHash[key] = hash;
		pruneOld(dir, static_cast<int>(mod->getSettingValue<int64_t>("max-backups")));
		log::info("Бэкап уровня '{}' -> {}", name, path.string());
	}
}

// Бэкап при ручном сохранении из редактора
class $modify(BackupPauseLayer, EditorPauseLayer) {
	void saveLevel() {
		EditorPauseLayer::saveLevel();
		if (Mod::get()->getSettingValue<bool>("backup-on-save")) {
			auto level = m_editorLayer->m_level;
			backupLevel(level, std::string(level->m_levelString));
		}
	}
};

// Периодический автобэкап, пока открыт редактор
class $modify(BackupEditorLayer, LevelEditorLayer) {
	bool init(GJGameLevel* level, bool noUI) {
		if (!LevelEditorLayer::init(level, noUI)) return false;

		auto minutes = Mod::get()->getSettingValue<int64_t>("interval-minutes");
		if (minutes > 0) {
			this->schedule(schedule_selector(BackupEditorLayer::onBackupTick), static_cast<float>(minutes * 60));
		}
		return true;
	}

	void onBackupTick(float) {
		// getLevelString() не трогает сам уровень — только читает текущее состояние
		backupLevel(m_level, std::string(this->getLevelString()));
	}
};
