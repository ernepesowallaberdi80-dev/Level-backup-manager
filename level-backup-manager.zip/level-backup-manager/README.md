# Level Backup Manager

Бэкапы уровней из редактора -> `<save dir мода>/backups/<название уровня>/ГГГГММДД_ЧЧММСС.gmd`

## Сборка
1. Установите Geode SDK и CLI: https://docs.geode-sdk.org/getting-started/
2. `geode build` в папке проекта
3. Готовый `.geode` файл появится в `build/`; положите его в `geode/mods` или установите через `geode package install`.

Перед сборкой замените `yourname` в `mod.json` на свой ник.
